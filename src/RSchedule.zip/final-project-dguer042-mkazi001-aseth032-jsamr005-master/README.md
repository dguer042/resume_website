# MySchedule
 > Authors: [Mohan Kazi](https://github.com/mohan-kazi), [Arav Seth](https://github.com/kozzza), [Jaswant Samra](https://github.com/JaswantSamra), [Dilan Guerrero](https://github.com/dguer042)

## Project Description
The application we plan to create is meant to help UCR students view and find their daily classes. We all shared the same problem at the beginning of the quarter of mixing up buildings, and forgetting class times. We aim to solve these issues with our app. We plan on using Flutter (with Dart) to develop the frontend of our app and Python for the backend.

## Class Diagram

![project uml](https://user-images.githubusercontent.com/21047756/166185777-7e79bb1f-feb8-40d7-abb8-5facc1fbbb11.png)

The backend consists of a login payload and a course payload that get sent to UCR's API endpoints in order to fetch information from them. These payloads are actually schemas built with ``pydantic`` in Python. Internally, a ``Schedule`` and a ``Course`` class exist which are associated as a ``Schedule`` consists of an exists as an of courses. The ``Course`` class has many attributes needed to show information about the course such as meeting times and location. The frontend has a class named ``DaySchedule`` which has all the courses for the day and the name of the current day. The ``DaySchedule`` also has a function named ``getCourseByCRN`` which returns a ``Course`` object (on the frontend) by iterating through the course numbers.

 > ## Phase III
We used the composite design pattern for our project. The reason we used it is to make the client interaction as simple as possible. By viewing the day schedule as a composite and a course as a primative, it helped us better visualize the process. The features we were able to implement were allowing the user to add, delete, and edit their courses should the need ever arise. For example, if we student's class was cancelled for the day, they could delete it from their schedule. This helped us write better code by helping us make the interaction with the user more simple.

![updated project uml](https://user-images.githubusercontent.com/102641020/169642346-329f6369-b203-4040-b6b4-a394403221c6.png)
 
 > ## Final deliverable
 ## Screenshots
 ![login page](https://user-images.githubusercontent.com/102641020/171969803-1aa87f3f-4ac3-40ef-9e54-d218a838d5f5.png)
 ![homepage](https://user-images.githubusercontent.com/102641020/171970089-99b62552-773d-46d8-82e6-55982c4972b2.png)
 ## Installation/Usage
 > In order to install and run application, user would just need to go to their app store on their phone and download the app.
 ## Testing
 > It was tested by using one of our own NETID logins, and then seeing if our schedule succesfully displayed with no issues. This was done with multiple NETIDs to make sure it worked consistently. API used also already ran tests that were premade. 
 
