import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import traceback

import uvicorn
from core.main import authenticate, fetch_schedule
from core.schemas import AuthAPIResponse, AuthPayload, ScheduleAPIResponse, Settings
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(docs_url="/")
settings = Settings()

origins = [
    "http://127.0.0.1",
    "https://127.0.0.1",
    "http://127.0.0.1:*",
    "https://127.0.0.1:*",
    "http://localhost:*/*",
    "https://localhost:*/*",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post(
    "/authenticate",
    response_model=AuthAPIResponse,
    response_model_exclude_none=True,
)
def verify_credentials(
    auth_payload: AuthPayload,
):
    """
    Authenticate user credentials

    :param auth_payload:
    """
    try:
        authenticated = authenticate(auth_payload.username, auth_payload.password)

        if authenticated:
            return dict(
                status_code=200,
                message="Success",
                data={"authenticated": True},
            )
        else:
            return dict(
                status_code=401,
                message="Invalid credentials",
                data={"authenticated": False},
            )
    except Exception:
        return dict(
            status_code=500,
            message=traceback.format_exc(),
        )


@app.post(
    "/schedule",
    response_model=ScheduleAPIResponse,
    response_model_exclude_none=True,
)
def get_schedule(
    auth_payload: AuthPayload,
):
    """
    Generate barcode id

    :param barcode_payload:
    """
    try:
        schedule = fetch_schedule(
            auth_payload.username,
            auth_payload.password,
        )
        if not schedule:
            return dict(
                status_code=401,
                message="Invalid credentials",
                data={},
            )
        return dict(
            status_code=200,
            message="Success",
            data=schedule,
        )
    except Exception as e:
        return dict(
            status_code=500,
            message=traceback.format_exc(),
        )


def init_webhooks(base_url):
    # Update inbound traffic via APIs to use the public-facing ngrok URL
    pass


if __name__ == "__main__":
    if settings.USE_NGROK:
        from pyngrok import ngrok

        # Get the dev server port (defaults to 8000 for Uvicorn, can be overridden with `--port`
        # when starting the server
        port = sys.argv[sys.argv.index("--port") + 1] if "--port" in sys.argv else 8000

        # Open a ngrok tunnel to the dev server
        public_url = ngrok.connect(port).public_url
        print('ngrok tunnel "{}" -> "http://127.0.0.1:{}"'.format(public_url, port))

        # Update any base URLs or webhooks to use the public ngrok URL
        settings.BASE_URL = public_url
        init_webhooks(public_url)

    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
