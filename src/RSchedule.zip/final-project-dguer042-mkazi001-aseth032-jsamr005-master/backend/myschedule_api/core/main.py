import os
import sys
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.driver import Driver

driver = Driver()


def authenticate(
    username: str,
    password: str,
) -> bool:
    """
    Authenticate user with username and password.

    :param username: username
    :param password: password

    :return: True if authentication was successful, False otherwise
    """

    execution = driver.get_execution()
    referer = driver.login(execution, username, password)

    if "?ticket=ST" in referer:
        return True
    else:
        return False


def fetch_schedule(
    username: str,
    password: str,
) -> tuple:
    """
    Fetch schedule for term.

    :param username: username
    :param password: password

    :return: json containing schedule information
    """

    execution = driver.get_execution()
    referer = driver.login(execution, username, password)

    if "?ticket=ST" not in referer:
        return {}

    now = datetime.now()
    term_year = now.year

    if now > datetime(term_year, 9, 19):
        term_mo = 40
    elif now > datetime(term_year, 6, 20):
        term_mo = 30
    elif now > datetime(term_year, 3, 23):
        term_mo = 20
    elif now > datetime(term_year, 1, 3):
        term_mo = 10

    registration_info = driver.get_registration_info(f"{term_year}{term_mo}")
    schedule = driver.parse_schedule(registration_info)

    return schedule
