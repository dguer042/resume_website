import os
from datetime import datetime
from pprint import pprint
from typing import Dict, List, Optional

from decouple import config
from pydantic import BaseModel, BaseSettings, root_validator


# Settings Model
class Settings(BaseSettings):
    BASE_URL = "http://127.0.0.1:8000"
    USE_NGROK = config("USE_NGROK", "False") == "True"


# Login Model(s)
class AuthPayload(BaseModel):
    """API auth payload model"""

    username: str
    password: str


# Response Model(s)
class AuthData(BaseModel):
    """API auth data model"""

    authenticated: Optional[bool]


class AuthAPIResponse(BaseModel):
    """API auth response model"""

    status_code: int
    error: Optional[bool]
    message: Optional[str] = ""
    data: Optional[AuthData] = {}

    # work around (waiting on https://github.com/samuelcolvin/pydantic/pull/2625)
    @root_validator
    def compute_error(cls, values) -> Dict:
        error = False if values.get("status_code") < 400 else True

        values["error"] = error
        return values

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "error": False,
                "message": "Success",
                "data": {
                    "authenticated": True,
                },
            }
        }


class ScheduleData(BaseModel):
    """API schedule data model"""

    subject: str
    subject_level: str
    course_number: int
    course_title: str
    course_section: int
    instructor_name: str
    building: str
    room: str
    is_online: bool
    start_time: datetime
    end_time: datetime


class ScheduleAPIResponse(BaseModel):
    """API schedule response model"""

    status_code: int
    error: Optional[bool]
    message: Optional[str] = ""
    data: Optional[Dict[int, List[ScheduleData]]] = {}

    # work around (waiting on https://github.com/samuelcolvin/pydantic/pull/2625)
    @root_validator
    def compute_error(cls, values) -> Dict:
        error = False if values.get("status_code") < 400 else True

        values["error"] = error
        return values

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "error": False,
                "message": "Success",
                "data": {
                    "authenticated": True,
                },
            }
        }
