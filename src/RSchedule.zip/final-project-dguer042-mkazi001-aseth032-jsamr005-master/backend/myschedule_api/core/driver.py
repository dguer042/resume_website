from datetime import datetime
from pprint import pprint
from urllib.parse import quote

import requests


class Driver:
    ses = requests.Session()

    def __init__(
        self,
    ):
        self.execution = ""

    def get_execution(
        self,
    ) -> str:
        """
        Extract execution string from login page

        :return: execution string
        """
        self.ses.cookies.clear()
        url = "https://auth.ucr.edu/cas/login?service=https%3A%2F%2Finnosoftfusiongo.com%2Fsso%2Flogin%2Flogin-process-cas.php"

        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X)"
                " AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
            ),
            "Accept-Language": "en-us",
            "Referer": "https://innosoftfusiongo.com/sso/login/login-start.php?id=124",
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip, deflate, br",
        }
        resp = self.ses.get(url, headers=headers)

        execution = resp.text.split('name="execution" value="')[1].split('"')[0]
        return execution

    def login(
        self,
        execution: str,
        username: str,
        password: str,
    ) -> str:
        """
        Send login paylaod to UCR CAS endpoint

        :param execution: execution string from login page
        :param username: username
        :param password: password

        :return: url with ST query parameter
        """
        url = "https://auth.ucr.edu/cas/login?service=https%3A%2F%2Finnosoftfusiongo.com%2Fsso%2Flogin%2Flogin-process-cas.php"

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "https://auth.ucr.edu",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X)"
                " AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
            ),
            "Referer": "https://auth.ucr.edu/cas/login?service=https%3A%2F%2Finnosoftfusiongo.com%2Fsso%2Flogin%2Flogin-process-cas.php",
            "Accept-Language": "en-US",
        }

        payload = f"username={quote(username)}&password={quote(password)}&execution={quote(execution)}&_eventId=submit&geolocation="

        resp = self.ses.post(url, headers=headers, data=payload)

        return resp.url

    def get_registration_info(
        self,
        term: str,
    ) -> dict:
        """
        Get information from registration endpoint

        :param term: term to get registration info for

        :return: registration info
        """
        url = f"https://registrationssb.ucr.edu/StudentRegistrationSsb/ssb/registrationHistory/reset?term={term}"

        headers = {
            "Accept": "*/*",
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X)"
                " AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
            ),
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip, deflate, br",
        }

        resp = self.ses.get(url, headers=headers)

        return resp.json()

    def parse_schedule(
        self,
        registration_info: dict,
    ) -> dict:
        """
        Parse schedule from registration info

        :param registration_info: registration info

        :return: schedule
        """

        schedule = {
            0: [],
            1: [],
            2: [],
            3: [],
            4: [],
            5: [],
            6: [],
        }

        week_map = {
            "sunday": 0,
            "monday": 1,
            "tuesday": 2,
            "wednesday": 3,
            "thursday": 4,
            "friday": 5,
            "saturday": 6,
        }

        for course in registration_info["data"]["registrations"]:
            if course["meetingTimes"]:
                course_info = {
                    "subject": course["subject"],
                    "subject_level": course["courseNumber"],
                    "course_number": int(course["courseReferenceNumber"]),
                    "course_title": course["courseTitle"],
                    "course_section": int(course["sequenceNumber"]),
                    "instructor_name": course["instructorNames"][0],
                    "building": course["meetingTimes"][0]["buildingDescription"],
                    "room": course["meetingTimes"][0]["room"],
                    "is_online": course["meetingTimes"][0]["building"] == "ONLINE",
                    "start_time": datetime.strptime(
                        course["meetingTimes"][0]["beginTime"], "%H%M"
                    ),
                    "end_time": datetime.strptime(
                        course["meetingTimes"][0]["endTime"], "%H%M"
                    ),
                }

            for day in week_map.keys():
                if course["meetingTimes"]:
                    if course["meetingTimes"][0][day]:
                        schedule[week_map[day]].append(course_info)

        return schedule
