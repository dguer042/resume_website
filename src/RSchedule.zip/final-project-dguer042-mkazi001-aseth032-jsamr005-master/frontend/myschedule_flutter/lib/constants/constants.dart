import 'package:flutter/material.dart';

class Constants {
  static const dark = Color.fromRGBO(55, 59, 74, 1.0);
  static const lightGrey = Color.fromRGBO(205, 208, 208, 1.0);
  static const purple = Color.fromRGBO(163, 71, 176, 1.0);
  static const lightPurple = Color.fromRGBO(223, 156, 226, 1.0);

  static const daysMap = {
    0: "Sunday",
    1: "Monday",
    2: "Tuesday",
    3: "Wednesday",
    4: "Thursday",
    5: "Friday",
    6: "Saturday",
  };
}
