class AuthData {
  bool authenticated;

  AuthData(this.authenticated);

  factory AuthData.fromJson(dynamic json) {
    return AuthData(
      json['authenticated'] as bool,
    );
  }
}

class AuthResponse {
  int statusCode;
  bool error;
  String message;
  AuthData data;

  AuthResponse(this.statusCode, this.error, this.message, this.data);

  factory AuthResponse.fromJson(dynamic json) {
    return AuthResponse(
      json['status_code'] as int,
      json['error'] as bool,
      json['message'] as String,
      AuthData.fromJson(
        json['data'],
      ),
    );
  }
}

class ScheduleData {
  String? subject;
  String? subjectLevel;
  int? courseNumber;
  String? courseTitle;
  int? courseSection;
  String? instructorName;
  String? building;
  String? room;
  bool? isOnline;
  String? startTime;
  String? endTime;

  ScheduleData(
    this.subject,
    this.subjectLevel,
    this.courseNumber,
    this.courseTitle,
    this.courseSection,
    this.instructorName,
    this.building,
    this.room,
    this.isOnline,
    this.startTime,
    this.endTime,
  );

  factory ScheduleData.fromJson(dynamic json) {
    return ScheduleData(
      json['subject'] as String?,
      json['subject_level'] as String?,
      json['course_number'] as int?,
      json['course_title'] as String?,
      json['course_section'] as int?,
      json['instructor_name'] as String?,
      json['building'] as String?,
      json['room'] as String?,
      json['is_online'] as bool?,
      json['start_time'] as String?,
      json['end_time'] as String?,
    );
  }
}

class ScheduleDay {
  String day;
  List courses;

  ScheduleDay(
    this.day,
    this.courses,
  );

  factory ScheduleDay.fromJson(dynamic json) {
    List coursesList = List<ScheduleData>.from(
      json["courses"].map(
        (model) => ScheduleData.fromJson(model),
      ),
    );

    return ScheduleDay(
      json['day'] as String,
      coursesList,
    );
  }
}

class ScheduleResponse {
  int statusCode;
  bool error;
  String message;
  Map data;

  ScheduleResponse(this.statusCode, this.error, this.message, this.data);

  factory ScheduleResponse.fromJson(dynamic json) {
    return ScheduleResponse(
      json['status_code'] as int,
      json['error'] as bool,
      json['message'] as String,
      json['data'] as Map,
    );
  }
}
