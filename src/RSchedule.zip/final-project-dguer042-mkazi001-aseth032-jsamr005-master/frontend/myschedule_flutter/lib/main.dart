import 'package:flutter/material.dart';
import 'package:myschedule_flutter/views/login.dart';
import 'package:myschedule_flutter/views/home.dart';
import 'package:myschedule_flutter/datastore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  DataStore datastore = DataStore();
  String username = await datastore.read("username");
  String password = await datastore.read("password");

  runApp(
    MaterialApp(
      title: 'MySchedule',
      home: (username != "" || password != "") ? HomePage() : LoginPage(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
