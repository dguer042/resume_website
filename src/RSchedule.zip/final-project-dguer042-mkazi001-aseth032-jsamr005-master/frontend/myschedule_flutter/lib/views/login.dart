import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../myschedule_api.dart';
import 'package:myschedule_flutter/views/home.dart';
import '../constants/constants.dart';
import '../datastore.dart';

Future<bool> getSchedule(username, password) async {
  final result = await fetchSchedule(username, password);
  if (result.statusCode == 200) {
    DataStore datastore = DataStore();
    await datastore.save('username', username);
    await datastore.save('password', password);
    await datastore.save("schedule_map", result.data);

    return true;
  } else {
    return false;
  }
}

class LoginPage extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<LoginPage> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final welcomeText = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: RichText(
        textAlign: TextAlign.left,
        text: TextSpan(
          style: GoogleFonts.lato(
            textStyle: const TextStyle(
              color: Colors.white,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          children: const <TextSpan>[
            TextSpan(text: 'Welcome to '),
            TextSpan(
              text: 'MySchedule',
              style: TextStyle(
                color: Constants.lightPurple,
              ),
            ),
          ],
        ),
      ),
    );
    final loginText = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        'Login to load your term schedule.',
        textAlign: TextAlign.left,
        style: GoogleFonts.lato(
          textStyle: const TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.normal,
          ),
        ),
      ),
    );
    final disclaimerText = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        '*Your credentials are not stored anywhere except for on this device.',
        textAlign: TextAlign.left,
        style: GoogleFonts.lato(
          textStyle: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.normal,
          ),
        ),
      ),
    );

    final loginForm = LoginForm(usernameController, passwordController);

    final body = Center(
      child: ListView(
        shrinkWrap: true,
        children: <Widget>[welcomeText, loginText, loginForm, disclaimerText],
      ),
    );

    return Scaffold(
      backgroundColor: Constants.dark,
      body: body,
    );
  }
}

class LoginForm extends StatefulWidget {
  final TextEditingController usernameController;
  final TextEditingController passwordController;

  LoginForm(this.usernameController, this.passwordController);

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  bool buttonEnabled = true;
  bool invalidCredentials = false;
  bool isAnimating = false;
  bool showPassword = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: SizedBox(
            height: 50,
            child: Focus(
              onFocusChange: (hasFocus) {
                if (hasFocus) {
                  setState(() => invalidCredentials = false);
                }
              },
              child: TextField(
                style: const TextStyle(
                  color: Colors.white,
                ),
                enableSuggestions: false,
                autocorrect: false,
                controller: widget.usernameController,
                decoration: InputDecoration(
                  enabledBorder: UnderlineInputBorder(
                    borderSide: invalidCredentials
                        ? const BorderSide(
                            width: 1,
                            color: Colors.red,
                          )
                        : const BorderSide(
                            width: 1,
                            color: Constants.lightPurple,
                          ),
                  ),
                  focusedBorder: const UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Constants.purple,
                    ),
                  ),
                  hintText: 'R\'Web Username',
                  hintStyle: const TextStyle(
                    color: Constants.lightGrey,
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding:
              const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 16),
          child: SizedBox(
            height: 50,
            child: Focus(
              onFocusChange: (hasFocus) {
                if (hasFocus) {
                  setState(() => invalidCredentials = false);
                }
              },
              child: TextField(
                style: const TextStyle(
                  color: Colors.white,
                ),
                obscureText: !showPassword,
                enableSuggestions: false,
                autocorrect: false,
                controller: widget.passwordController,
                decoration: InputDecoration(
                  enabledBorder: UnderlineInputBorder(
                    borderSide: invalidCredentials
                        ? const BorderSide(
                            width: 1,
                            color: Colors.red,
                          )
                        : const BorderSide(
                            width: 1,
                            color: Constants.lightPurple,
                          ),
                  ),
                  focusedBorder: const UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Constants.purple,
                    ),
                  ),
                  hintText: 'R\'Web Password',
                  hintStyle: const TextStyle(
                    color: Constants.lightGrey,
                  ),
                  suffixIcon: GestureDetector(
                    onTap: () => setState(() => showPassword = !showPassword),
                    child: Icon(
                      showPassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: SizedBox(
            height: 50,
            width: double.infinity,
            child: TextButton(
              style: ButtonStyle(
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                backgroundColor:
                    MaterialStateProperty.all<Color>(Constants.purple),
              ),
              onPressed: () async {
                if (buttonEnabled &&
                    widget.usernameController.text != "" &&
                    widget.passwordController.text != "") {
                  FocusScope.of(context).unfocus();
                  setState(() {
                    isAnimating = true;
                    buttonEnabled = false;
                  });
                  if (await getSchedule(widget.usernameController.text,
                      widget.passwordController.text)) {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomePage(),
                      ),
                    );
                  } else {
                    setState(() => isAnimating = false);
                    setState(() => invalidCredentials = true);
                  }
                  buttonEnabled = true;
                }
              },
              child: isAnimating
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: Colors.white,
                        ),
                      ),
                    )
                  : Text(
                      "Verify",
                      style: GoogleFonts.lato(
                        textStyle: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
            ),
          ),
        )
      ],
    );
  }
}
