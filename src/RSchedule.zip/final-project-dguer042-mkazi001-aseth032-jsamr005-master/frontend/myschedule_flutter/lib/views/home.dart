import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myschedule_flutter/views/login.dart';
import '../constants/constants.dart';
import '../models/models.dart';
import '../datastore.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<HomePage> {
  late ScheduleDay scheduleDay;
  final dayOfTheWeek = DateTime.now().weekday == 7 ? 0 : DateTime.now().weekday;
  bool loading = true;

  @override
  initState() {
    super.initState();
    readSchedule().then((value) {
      setState(() {
        scheduleDay = value;
        loading = false;
      });
    });
  }

  Future<ScheduleDay> readSchedule() async {
    DataStore datastore = DataStore();

    Map scheduleMap =
        await datastore.read("schedule_map") as Map<String, dynamic>;
    scheduleMap.forEach((key, value) {
      scheduleMap[key] = ScheduleDay.fromJson({"day": key, "courses": value});
    });

    scheduleDay = scheduleMap[dayOfTheWeek.toString()];
    return scheduleDay;
  }

  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove("username");
    await prefs.remove("password");

    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return CircularProgressIndicator();

    final courseCards = CourseCardsWidget(scheduleDay);
    final body = Center(
      child: courseCards,
    );

    return Scaffold(
      backgroundColor: Constants.dark,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Constants.lightPurple,
        title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              SizedBox(
                width: 60,
              ),
              FittedBox(
                child: Text(
                  Constants.daysMap[int.parse(scheduleDay.day)]!,
                  style: GoogleFonts.lato(
                    textStyle: const TextStyle(
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                width: 60,
                child: IconButton(
                    icon: Image.asset('assets/images/arrow.png'),
                    iconSize: 60,
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LoginPage(),
                        ),
                      );
                    }),
              ),
            ]),
      ),
      body: body,
    );
  }
}

class CourseCardsWidget extends StatefulWidget {
  final ScheduleDay scheduleDay;

  CourseCardsWidget(this.scheduleDay);

  @override
  _CourseCardsWidgetState createState() => _CourseCardsWidgetState();
}

class _CourseCardsWidgetState extends State<CourseCardsWidget> {
  late String focusedCourseTitle;

  @override
  Widget build(BuildContext context) {
    final courses = widget.scheduleDay.courses;
    setState(() {
      focusedCourseTitle = courses[0].courseTitle;
    });

    int _index = 0;

    print(courses.length);
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        child: ListView.builder(
          itemCount: courses.length,
          itemBuilder: (context, i) {
            final course = courses[i];
            String stFormatted =
                DateFormat('hh:mm a').format(DateTime.parse(course.startTime));
            String etFormatted =
                DateFormat('hh:mm a').format(DateTime.parse(course.endTime));

            return Container(
              height: 400,
              child: Card(
                color: Colors.grey[900],
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                margin: EdgeInsets.all(10.0),
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Text(
                              "${course.subject} ${course.courseNumber}",
                              style: TextStyle(
                                  fontSize: 18, color: Constants.lightGrey),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(14.0),
                            child: Text(
                              "Section ${course.courseSection.toString().padLeft(2, '0')}",
                              style: TextStyle(
                                  fontSize: 18, color: Constants.lightGrey),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(13.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: Text(
                              course.courseTitle,
                              style:
                                  TextStyle(fontSize: 36, color: Colors.white),
                              maxLines: 2,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(13.0),
                        child: Row(
                          children: [
                            Text(
                              stFormatted,
                              style: TextStyle(
                                  fontSize: 48, color: Constants.purple),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 15),
                              child: Text(
                                " - ${etFormatted}",
                                style: TextStyle(
                                    fontSize: 24, color: Constants.lightGrey),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(13.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: InkWell(
                                child: Text(
                                  course.building,
                                  style: TextStyle(
                                      decoration: TextDecoration.underline,
                                      fontSize: 36,
                                      color: Colors.white),
                                ),
                                onTap: () {
                                  launch(
                                      "https://www.google.com/maps/place/${course.building.trim().replaceAll(' ', '+')},+Riverside,+CA+92507");
                                }),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(13.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: Text(
                              "Room ${course.room}",
                              style:
                                  TextStyle(fontSize: 24, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(14.0),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            course.instructorName,
                            style: TextStyle(
                                fontSize: 18, color: Constants.lightGrey),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
