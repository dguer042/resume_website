import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'models/models.dart';

const url = 'http://d1b2-169-235-89-204.ngrok.io';

authenticate(String username, String password) async {
  try {
    final response = await http.post(
      Uri.parse('$url/authenticate'),
      headers: <String, String>{
        'Content-Type': 'Application/json',
      },
      body: jsonEncode(
          <String, String>{'username': username, 'password': password}),
    );
    final jsonResponse = jsonDecode(response.body);
    if (jsonResponse['status_code'] == 500) {
      return {};
    }
    return AuthResponse.fromJson(jsonResponse);
  } on SocketException {
    return {};
  }
}

fetchSchedule(String username, String password) async {
  try {
    final response = await http.post(
      Uri.parse('$url/schedule'),
      headers: <String, String>{
        'Content-Type': 'Application/json',
      },
      body: jsonEncode(<String, String>{
        'username': username,
        'password': password,
      }),
    );

    final jsonResponse = jsonDecode(response.body);
    if (jsonResponse['status_code'] == 500) {
      print(response.body);
      return {};
    }
    return ScheduleResponse.fromJson(jsonResponse);
  } catch (e) {
    print(e);
    return {};
  }
}
